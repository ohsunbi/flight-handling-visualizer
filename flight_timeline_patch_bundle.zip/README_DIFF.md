# Patch instructions

Paste the contents of `plotting_patch_snippet.py` to replace your current plotting section starting from:

    # ---- Top panel: classic split ----

down to your current overlap/second-chart code and the final two `st.pyplot(...)` calls.
The snippet already renders `fig1` and removes the separate overlap chart.

## Color palette
- Departure: #1f77b4
- Arrival: #d62728
- Departure (extra): #17becf
- Arrival (extra): #ff7f0e

Markers: Extra uses diamond (marker='D'); base uses circle.

Legend: Always shows 4 categories with correct colors and styles.

Overlap counts: Two numeric rows under the timeline (top row = Departure, bottom row = Arrival). Higher counts are drawn with higher alpha (darker). The interval matches your `interval_min` control.

